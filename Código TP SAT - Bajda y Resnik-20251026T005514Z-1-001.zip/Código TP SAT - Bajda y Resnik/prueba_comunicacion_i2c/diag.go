package main

import (
	"fmt"
	"machine"
	"time"
)

func main() {
	i2c := machine.I2C0
	i2c.Configure(machine.I2CConfig{
		SCL:       machine.GPIO5, // SCL en GPIO5
		SDA:       machine.GPIO4, // SDA en GPIO4
		Frequency: 400 * machine.KHz,
	})

	for {
		found := false
		for addr := uint16(0x08); addr <= 0x77; addr++ { // rango 7-bit válido
			// Hacemos un "probe" con un write de 1 byte (más confiable que nil,nil).
			if err := i2c.Tx(addr, []byte{0x00}, nil); err == nil {
				fmt.Printf("I2C OK en 0x%02X\n", addr)
				found = true
			}
		}
		if !found {
			fmt.Println("No se detectó ningún dispositivo I2C.")
		}
		fmt.Println("---- nueva búsqueda ----")
		time.Sleep(2 * time.Second)
	}
}
