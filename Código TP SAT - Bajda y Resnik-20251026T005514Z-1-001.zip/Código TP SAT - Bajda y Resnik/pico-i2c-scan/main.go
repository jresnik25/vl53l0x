package main

import (
	"fmt"
	"machine"
	"time"
)

func main() {
	// I2C0 en la Pico: SCL=GPIO5 (pin 7), SDA=GPIO4 (pin 6)
	i2c := machine.I2C0
	i2c.Configure(machine.I2CConfig{
		SCL:       machine.GPIO5, // si TinyGo se queja, usá machine.GP5 / machine.GP4
		SDA:       machine.GPIO4,
		Frequency: 100 * machine.KHz, // empezamos a 100 kHz para estabilidad
	})

	for {
		found := false
		for addr := uint16(0x08); addr <= 0x77; addr++ {
			// Probe más confiable: intento de escribir el registro 0x00
			if err := i2c.Tx(addr, []byte{0x00}, nil); err == nil {
				// Si es nuestro VL53L0X (0x29), leemos el ID (reg 0xC0)
				if addr == 0x29 {
					id := []byte{0}
					if err := i2c.Tx(addr, []byte{0xC0}, id); err == nil {
						fmt.Printf("I2C OK en 0x%02X  (VL53L0X ID=0x%02X)\n", addr, id[0])
					} else {
						fmt.Printf("I2C OK en 0x%02X  (VL53L0X detectado)\n", addr)
					}
				} else {
					fmt.Printf("I2C OK en 0x%02X\n", addr)
				}
				found = true
			}
		}
		if !found {
			fmt.Println("No se detectó ningún dispositivo I2C.")
		}
		fmt.Println("---- nueva búsqueda ----")
		time.Sleep(2 * time.Second)
	}
}
