package main

import (
	"machine"
	"time"

	"pico-vl53l0x-read/vl53l0x" // driver del sensor, lo tenemos local y lo importamos
)

const (
	// Determinamos umbrales para prender/apagar tres LEDs
	th1 = 100 // si la distancia que mide es menor, todos apagados. Si es mayor o igual, se prende.
	th2 = 300 // si es mayor o igual se prende un segundo LED (el primero se mantiene prendido)
	th3 = 500 // si es mayor o igual a 500mm, se prenden los tres LEDs
)

func halt(msg string, err error) { // para detección de error. interrumpe el programa
	if err != nil {
		println(msg, ":", err.Error())
		for {
			time.Sleep(time.Second)
		}
	}
}

func main() {
	i2c := machine.I2C0 // configuramos el bus I2C0 para la comunicación de la Pico con el sensor (dirección 0x29 por default)
	halt("I2C config", i2c.Configure(machine.I2CConfig{
		SCL:       machine.GPIO5,     // para SCL usamos el GPIO15 (pin 7)
		SDA:       machine.GPIO4,     // para SDA usamos el GPIO4 (pin 6)
		Frequency: 100 * machine.KHz, // se puede trabajar con frecuencias mas elevadas

	
	// Seteamos los LED (para que se prendan o apaguen según la distancia medida. A medida que supera umbrales va prendiendo LEDs)
	led1 := machine.GPIO14
	led2 := machine.GPIO15
	led3 := machine.GPIO16

	led1.Configure(machine.PinConfig{Mode: machine.PinOutput})
	led2.Configure(machine.PinConfig{Mode: machine.PinOutput})
	led3.Configure(machine.PinConfig{Mode: machine.PinOutput})

	setLEDs := func(mm uint16, ok bool) {
		// Queremos que arranque todo apagado
		led1.Low()
		led2.Low()
		led3.Low()

		// Para error o fuera de rango, no prende nada. Ojo: el sensor devuelve VL53L0X devuelve aprox 8190mm si está fuera de rango
		if !ok || mm >= 8000 {
			return
		}

		switch { // para ir prendiendo los LEDs según los umbrales que seteamos al principio
		case mm >= th3:
			led1.High()
			led2.High()
			led3.High()
		case mm >= th2:
			led1.High()
			led2.High()
		case mm >= th1:
			led1.High()
		default:
			// si es menor a < th1 -> ningún LED se prende
		}
	}

	// inicializamos el sensor VL53L0X 
	s := vl53l0x.NewVl53l0x()
	halt("Init", s.Init(i2c)) //arranque y calibración
	halt("Config", s.Config(i2c, vl53l0x.LongRange, vl53l0x.HighAccuracy)) //perfil de alcance y precisión

	// Lectura -> en cada bucle: mide, muestra la distancia en el terminal y actualiza los LED según lo que midió
	for {
		d, err := s.ReadRangeSingleMillimeters(i2c)
		if err != nil {
			println("lectura:", err.Error())
			setLEDs(0, false) // error: LEDs  apagados
		} else {
			println("distancia:", d, "mm")
			setLEDs(d, true) // segun la distancia, actualiza el estado de los LED
		}
		time.Sleep(500 * time.Millisecond) // ritmo de actualizar, se puede poner más rapido,  pusimos asi para facilitar la interpretación
	}
}
